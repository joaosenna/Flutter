import 'package:financas_pessoais/database/database_manager.dart';
import 'package:financas_pessoais/models/categorial.dart';
import 'package:financas_pessoais/models/tipo_lancamento.dart';

class InvestimentoRepository {
  Future<List<Investimento>> listarInvestimentos() async {
    final db = await DatabaseManager().getDatabase();

    // Listar Investimentos do Banco de dados
    // Retorna uma Lista de Map (chave/valor)
    // onde a chave é o nome da coluna no banco de dados
    final List<Map<String, dynamic>> rows = await db.query('investimentos');

    // Mapear a lista de <Map> para uma lista de <Investimentos>
    return rows
        .map(
          (row) => Investimento(
              id: row['id'],
              investimentoTipo: row['investimentoTipo'],
              investimentoValorInicial: row['investimentoValorInicial'],
              investimentoValorAtualizado: row['investimentoValorAtualizado'],
              rendimentoAcumulado: row['rendimentoAcumulado']
              dataInicial: row['dataInicial']
              dataAtual: row['dataAtual']
              
        )
        .toList();
  }
}

