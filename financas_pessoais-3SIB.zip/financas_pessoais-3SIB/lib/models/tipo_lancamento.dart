enum TipoTransacao { despesa, receita }
