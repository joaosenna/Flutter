

class Investimento{
  int id;
  String investimentoTipo;
  double investimentoValorInicial;
  double investimentoValorAtualizado;
  double rendimentoAcumulado;
  DateTime dataInicial;
  DateTime dataAtual;

  Investimento({
    required this.id,
    required this.investimentoValorInicial;
    required this.investimentoValorAtualizado;
    required this.rendimentoAcumulado;
    DateTime dataInicial;
    DateTime dataAtual;
  });
}