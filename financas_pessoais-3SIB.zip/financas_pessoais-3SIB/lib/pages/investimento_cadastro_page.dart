
import 'package:financas_pessoais/models/investimento.dart';
import 'package:financas_pessoais/repository/investimento_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:intl/intl.dart';


class InvestimentoCadastroPage extends StatefulWidget {
  Investimento? investimentoParaEdicao;
  investimentoCadastroPage({Key? key, this.investimentoParaEdicao}) : super(key: key);

  @override
  State<InvestimentoCadastroPage> createState() => _InvestimentoCadastroPageState();
}

class _InvestimentoCadastroPageState extends State<InvestimentoCadastroPage> {
  final _investimentoRepository = InvestimentoRepository();
  final _valorInicialController = MoneyMaskedTextController(
      decimalSeparator: ',', thousandSeparator: '.', leftSymbol: 'R\$');

  final _dataInicialController = TextEditingController();
  final _investimentoTipoController = TextEditingController();


  Investimento? _investimentoSelecionado;
  
  List<Investimento> _investimentos = [];

  @override
  void initState() {
    super.initState();

    final investimento = widget.investimentoParaEdicao;
    if (investimento != null) {
      _investimentoSelecionado = investimento.investimentoTipo;
      _valorInicialController.text =
          NumberFormat.simpleCurrency(locale: 'pt_BR').format(investimento.investimentoValorInicial);
      _dataInicialController.text = DateFormat('MM/dd/yyyy').format(investimento.dataInicialController);
    }

    carregarInvestimentos();
  }

  Future<void> carregarInvestimentos() async {
    final investimentos = await _investimentoRepository.listarInvestimentos();

    setState(() {
      _investimentos = investimentos
          .where((c) => c.invetimentoTipo == tipoInvestimentoSelecionado)
          .toList();
    });
  }

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Novo Investimento'),
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                _buildTipoInvestimento(),
                const SizedBox(height: 20),
                _buildValorInicialInvestimento(),
                const SizedBox(height: 20),
                _buildData(),
                const SizedBox(height: 20),
                const Divider(),
                _buildButton()
              ],
            ),
          ),
        ),
      ),
    );
  }

  SizedBox _buildButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        child: const Padding(
          padding: EdgeInsets.all(10.0),
          child: Text('Cadastrar'),
        ),
        onPressed: () async {
          final isValid = _formKey.currentState!.validate();
          if (isValid) {
            final investimentoTipo = _investimentoTipoController.text;

            final investimento = _investimentoSelecionado!;
            final investimentoDataInicial = DateFormat('dd/MM/yyyy').parse(_dataController.text);
            final investimentoValorInicial = NumberFormat.currency(locale: 'pt_BR')
                .parse(_valorController.text.replaceAll('R\$', ''))
                .toDouble();

            final investimento = Investimento(
              investimentoTipo: investimentoTipo,
              investimentoValorInicial:investimentoValorInicial,
              investimentoDataInicial: investimentoDataInicial,
          
            );

           

            try {
              if (widget.investimentoParaEdicao != null) {
               investimento.id = widget.investimentoParaEdicao!.id;
                await _investimentoRepository.editarInvestimento(investimento);
              } else {
                await _investimentoRepository.cadastrarInvestimento(investimento);
              }

              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text('$investimentoTipo cadastrado com sucesso'),
              ));

              Navigator.of(context).pop(true);
            } catch (e) {
              Navigator.of(context).pop(false);
            }
          }
        },
      ),
    );
  }


  TextFormField _buildValor() {
    return TextFormField(
      controller: _valorController,
      decoration: const InputDecoration(
        hintText: 'Informe o valor',
        labelText: 'Valor',
        border: OutlineInputBorder(),
        prefixIcon: Icon(Icons.money),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Informe um Valor';
        }
        final valor = NumberFormat.currency(locale: 'pt_BR')
            .parse(_valorInicialController.text.replaceAll('R\$', ''));
        if (valor <= 0) {
          return 'Informe um valor maior que zero';
        }

        return null;
      },
    );
  }

  DropdownButtonFormField _buildTipoInvestimento() {
    return DropdownButtonFormField<Investimento>(
      value: _investimentoSelecionada,
      items: _investimento.map((i) {
        return DropdownMenuItem<Investimento>(
          value: i,
          child: Text(i.investimentoTipo),
        );
      }).toList(),
      onChanged: (Investimento? investimento) {
        setState(() {
          _investimentoSelecionado = investimento;
        });
      },
      decoration: const InputDecoration(
        hintText: 'Selecione  tipo de investimento',
        labelText: 'Tipo de Investimento',
        border: OutlineInputBorder(),
      ),
      validator: (value) {
        if (value == null) {
          return 'Informe um tipo de investimento';
        }
        return null;
      },
    );
  }

  TextFormField _buildData() {
    return TextFormField(
      controller: _dataController,
      decoration: const InputDecoration(
        hintText: 'Informe uma Data',
        labelText: 'Data',
        border: OutlineInputBorder(),
        prefixIcon: Icon(Icons.calendar_month),
      ),
      onTap: () async {
        FocusScope.of(context).requestFocus(FocusNode());

        DateTime? dataSelecionada = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime(2000),
          lastDate: DateTime(2100),
        );

        if (dataSelecionada != null) {
          _dataController.text =
              DateFormat('dd/MM/yyyy').format(dataSelecionada);
        }
      },
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Informe uma Data';
        }

        try {
          DateFormat('dd/MM/yyyy').parse(value);
        } on FormatException {
          return 'Formato de data inválida';
        }

        return null;
      },
    );
  }

}
