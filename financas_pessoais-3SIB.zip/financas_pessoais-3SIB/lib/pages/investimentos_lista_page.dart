import 'package:financas_pessoais/models/investimento.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class InvestimentoListaPage extends StatelessWidget {
  const InvestimentoListaPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final investimento = ModalRoute.of(context)!.settings.arguments as Investimento;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: red,
        title: Text(investimento.investimentoTipo),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            ListTile(
              title: const Text('Tipo de Investimento'),
              subtitle: Text(
                  ? 'Ações'
                  ? 'Renda Fixa'
                  ? 'Fundos de Investimento'
                  : 'Criptomoedas'),
            ),
            ListTile(
              title: const Text('Valor Inicial'),
              subtitle: Text(NumberFormat.simpleCurrency(locale: 'pt_BR')
                  .format(investimento.investimentoValorInicial)),
            ),
            ListTile(
              title: const Text('Data Atual'),
              subtitle: Text(DateFormat('MM/dd/yyyy').format(investimento.investimentoDataInicial)),
            ),

            ListTile(
              title: const Text('Data Atual'),
              subtitle: Text(DateFormat('MM/dd/yyyy').format(investimento.investimentoDataAtual)),
            ),
           ListTile(
              title: const Text('Rendimento Acumulado'),
              subtitle: Text(NumberFormat.simpleCurrency(locale: 'pt_BR')
                  .format(${investimento.investimentoValorInicial} - ${investimento.investimentoValorAtual})),
            ),
          ],
        ),
      ),
    );
  }
}
