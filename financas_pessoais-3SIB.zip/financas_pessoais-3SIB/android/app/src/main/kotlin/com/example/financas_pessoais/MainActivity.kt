package com.example.financas_pessoais

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
