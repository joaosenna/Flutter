import 'dart:convert';

import "package:http/http.dart" as http;

import '../../models/user.dart';


class GitHubApi{

  final baseUrl = "https://api.github.com/";

  Future <User?> searchUser(String userName) async {
    
    final url = "${baseUrl}users/$userName";
    
    var response = await http.get(Uri.parse(url));

    
    if( response.statusCode == 200){
      
    Map json = jsonDecode(response.body);

    return User.fromJson(json);
 
    } 
    
    return null;
    }

    Future<List<User>> getUserFollowing(String userName) async {
    //
    final url = "${baseUrl}users/$userName/following";

    var response = await http.get(Uri.parse(uri));


    List<User> users = 

}
}