package com.example.github_api_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
