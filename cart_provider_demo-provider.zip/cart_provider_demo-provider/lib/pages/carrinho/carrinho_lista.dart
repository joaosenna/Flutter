import 'package:flutter/material.dart';

class CarrinhoLista extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    print('BUILD: CarrinhoLista');

    var itemNameStyle = Theme.of(context).textTheme.titleLarge;

    return Container();
  }
}
