import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/carrinho.dart';

class CarrinhoLista extends StatelessWidget {

 

  @override
  Widget build(BuildContext context) {
    print('BUILD: CarrinhoLista');

   final carrinho = Provider.of<CarrinhoModel>(context);
    
    return ListView.builder( 
    itemCount: carrinho.items.length, 
    itemBuilder: (context, index){
    final item = carrinho.items[index];
    return ListTile(
    title: Text(carrinho.items[index].nome),
    subtitle: Text('R\$${item.preco}'),
    leading:Image(image: AssetImage('images/${index + 1}.jpeg')),
    trailing: IconButton(
      icon: const Icon(
        Icons.remove_circle,
        color: Colors.red,
        ),
        onPressed: (){
          carrinho.remove(item);}));
      
  }

);

    
}
}