package com.example.cart_provider_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
